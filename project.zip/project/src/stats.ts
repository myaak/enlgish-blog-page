import express = require("express")

//@ts-ignore
const pool = require('./db')

const router = express.Router()

//@ts-ignore
router.get("/likes", async(req:any, res:any ) => {
  const likes = await pool.query(
    "SELECT COUNT, DATE FROM LIKES_STATS ORDER BY DATE",
    []
  )
  let likesPerDate:any = []
  for(let i=0; i<likes.rowCount; ++i) {
    let date:string = String(likes.rows[i].date).substr(8,2)
    likesPerDate.push({
      date: date+"th",
      likes: likes.rows[i].count
    })
  }
  res.json(likesPerDate)
})

//@ts-ignore
router.get("/blogsLike", async(req:any, res:any) => {

//@ts-ignore
  const theBestBlog = await pool.query(
    "SELECT BLOG_ID, COUNT(ID) FROM LIKES GROUP BY BLOG_ID ORDER BY count DESC LIMIT 1",
    []
  )


  const blogsLike = await pool.query(
    "SELECT BLOG_ID, IMAGE, TITLE FROM BLOGS WHERE BLOG_ID = $1",
    [theBestBlog.rows[0].blog_id]
  ) 

  res.json({
    id: blogsLike.rows[0].blog_id,
    image: blogsLike.rows[0].image,
    title: blogsLike.rows[0].title,
    likes: theBestBlog.rows[0].count
  })
})

//@ts-ignore
router.get("/blogsComment", async(req:any, res:any) => {

  const theBestBlog = await pool.query(
    "SELECT BLOG_ID, COUNT(COMMENT_ID) FROM COMMENTS GROUP BY BLOG_ID ORDER BY count DESC LIMIT 1",
    []
  )

  const blogsComment = await pool.query(
    "SELECT BLOG_ID, IMAGE, TITLE FROM BLOGS WHERE BLOG_ID = $1",
    [theBestBlog.rows[0].blog_id]
  ) 

  res.json({
    id: blogsComment.rows[0].blog_id,
    image: blogsComment.rows[0].image,
    title: blogsComment.rows[0].title,
    comments: theBestBlog.rows[0].count
  })
})

//@ts-ignore
router.get("/users", async(req:any, res:any) => {
  
  const users = await pool.query(
    "SELECT COUNT, DATE FROM USERS_STATS ORDER BY DATE",
    []
  )
  let usersPerDate:any = []
  for(let i=0; i<users.rowCount; ++i) {
    let date:string = String(users.rows[i].date).substr(8,2)
    usersPerDate.push({
      date: date+"th",
      users: users.rows[i].count
    })
  }
  res.json(usersPerDate)
})

module.exports = router
