declare const validateForm: (req: any) => void;
export { validateForm };
